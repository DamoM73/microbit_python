# sound exercise 3

from microbit import *

# --- SETUP
# start sensors

# store variables

# --- RUNNING
while True:
    # read sensor data
    
    # process data
    
    # output data
    
# temperature exercise 1

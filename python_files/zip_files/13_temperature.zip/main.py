from microbit import *

# --- SETUP
# start components

# store variables

# --- RUNNING
while True:
    # read sensor data
    temp = temperature()
    
    # process data
    temp = str(temp) + "C"
    
    # output data
    display.scroll(temp)
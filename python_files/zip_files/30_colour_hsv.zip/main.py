from microbit import *
from PiicoDev_VEML6040 import PiicoDev_VEML6040

def classify_hue(hue):
    # returns the colour of a hue
    if 0 <= hue < 15 or 345 <= hue <= 360:
        return "Red"
    elif 15 <= hue < 45:
        return "Orange"
    elif 45 <= hue < 75:
        return "Yellow"
    elif 75 <= hue < 165:
        return "Green"
    elif 165 <= hue < 195:
        return "Cyan"
    elif 195 <= hue < 255:
        return "Blue"
    elif 255 <= hue < 285:
        return "Purple"
    elif 285 <= hue < 345:
        return "Magenta"
    else:
        return "Unknown Color"

# --- SETUP
# start components
colourSensor = PiicoDev_VEML6040()

# store variables
    

# --- RUNNING
while True:
    # read sensor data
    hsv_data = colourSensor.readHSV()
    
    # process data
    colour_read = classify_hue(hsv_data['hue'])
    hue = str(hsv_data['hue'])
    sat = str(hsv_data['sat'])
    val = str(hsv_data['val'])
    
    # output data
    print(colour_read, hue, sat, val)
    sleep(500)

from microbit import *
from PiicoDev_SSD1306 import *

# --- SETUP
# start sensors
oled = create_PiicoDev_SSD1306()

# store variables
line_width = 1

hline_length = 80
hline_x = 10
hline_y = 10

vline_length = 35
vline_x = 10
vline_y = 10

line_x1 = 10
line_y1 = 45
line_x2 = 90
line_y2 = 10

# --- RUNNING
while True:
    # read sensor data
    
    # process data
    
    # output data
    # horizontal line
    oled.hline(hline_x, hline_y, hline_length, line_width)
    oled.show()
    sleep(500)
    
    # verticle line
    oled.vline(vline_x, vline_y, vline_length, line_width)
    oled.show()
    sleep(500)
    
    # line between two points
    oled.line(line_x1, line_y1, line_x2, line_y2, line_width)
    oled.show()
    sleep(500)
    
    # clear screen
    oled.fill(0)
    oled.show()
    
    sleep(2000)

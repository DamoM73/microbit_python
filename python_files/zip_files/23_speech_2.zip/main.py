from microbit import *
import speech

# --- SETUP
# start components

# store variables
message = "MAOTUN BEY BOYS KAALLEYJ"

# --- RUNNING
while True:
    # read sensor data
    
    # process data
    
    # output data
    speech.say(message)
    
    sleep(1000)
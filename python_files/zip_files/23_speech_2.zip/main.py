from microbit import *
import speech

# --- SETUP
# start sensors

# store variables
message = "MAOTUN BEY BOYS KAALLEYJ"

# --- RUNNING
while True:
    # read sensor data
    
    # process data
    
    # output data
    speech.say(message)
    
    sleep(1000)
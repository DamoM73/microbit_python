from microbit import *
import music

# --- SETUP
# start components

# store variables

# --- RUNNING
while True:
    # read sensor data
    
    # process data
    
    # output data
    music.play(music.NYAN)
    
    sleep(500)
from microbit import *

# --- SETUP
# start components

# store vairables

# --- RUNNING
while True:
    # read sensor data
    
    # process data
    
    # output data
    display.show(3.14159, delay=500)
    display.clear()
    sleep(1000)
from microbit import *

# --- SETUP

# start sensors

# store variables
message = "Hello world!"

# --- RUNNING
while True:
    # read sensor data
    
    # process data
    
    # output data
    display.scroll(message)
    display.show(Image.HEART)
    sleep(1000)